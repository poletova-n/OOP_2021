package lab2.exceptions;

public class DividedByZero extends Exception {
    public DividedByZero(String message){
        super(message);
    }
}