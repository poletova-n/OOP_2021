package lab2.exceptions;

public class EmptyFile extends Exception {
    public EmptyFile(String message){
        super(message);
    }
}