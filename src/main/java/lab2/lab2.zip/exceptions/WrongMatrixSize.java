package lab2.exceptions;

public class WrongMatrixSize extends Exception{
    public WrongMatrixSize(String message){
            super(message);
    }
}
